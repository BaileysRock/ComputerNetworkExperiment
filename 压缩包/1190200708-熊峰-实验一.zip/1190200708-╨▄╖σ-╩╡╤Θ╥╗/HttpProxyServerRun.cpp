//
// Created by Alienware on 2021/10/29.
//

#include "Class/HttpProxyServer.h"


int main()
{
    HttpProxyServer httpProxyServer;

    httpProxyServer.HttpProxyServerStart();
//    httpProxyServer.ClearNetworkStatus();
    return 0;


}
